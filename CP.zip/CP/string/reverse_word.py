s=input()
print(s[::-1])
