s=input().split()
print(*[w[::-1] for w in s])
