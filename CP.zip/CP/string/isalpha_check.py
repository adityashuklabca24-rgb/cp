s=input()
print(1 if s.isalpha() else 0)
