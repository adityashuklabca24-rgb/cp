A=input()
B=input()
print(A.find(B))
