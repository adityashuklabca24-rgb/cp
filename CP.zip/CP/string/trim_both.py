s=input()
print(s.strip('*'))
