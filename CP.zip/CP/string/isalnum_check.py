s=input()
print(1 if s.isalnum() else 0)
