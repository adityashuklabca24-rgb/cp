s=input()
print(s.lower())
