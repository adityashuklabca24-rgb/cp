s=input()
print(len(s))
