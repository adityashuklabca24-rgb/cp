def test():
    lang = "Python"
    print(lang)

test()
