a = 4
square = lambda x: x * x
print(square(a))
