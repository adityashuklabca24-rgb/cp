def introduce(name, age, profession="Student"):
    print(name, age, profession)

introduce("Rahul", 20)
