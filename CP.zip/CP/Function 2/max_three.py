max_of_three = lambda a, b, c: a if a > b and a > c else b if b > c else c
print(max_of_three(3, 7, 2))
