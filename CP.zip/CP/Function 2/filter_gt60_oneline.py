ans = list(filter(lambda x: x > 60, list(map(int, input().split()))))
print(ans)
