num = int(input())
even_odd_No = lambda num: "even" if num % 2 == 0 else "odd"
print(even_odd_No(num))
