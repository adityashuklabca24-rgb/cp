def local():
    lang = "Python"
    print(lang)

local()
