names = ["Rahul", "AMIT", "Suyash"]
result = list(map(lambda x: x.lower(), names))
print(result)
