def introduce(name, age, profession):
    print(name, age, profession)

introduce(name="Rahul", age=20, profession="Student")
