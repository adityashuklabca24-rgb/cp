m = int(input("Enter the number: "))
n = int(input("Enter the number "))
result = 1
for _ in range(n):
    result =result*m

print("the answer is:",result)
