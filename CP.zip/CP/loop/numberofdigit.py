num = int(input("Enter a number: "))
digit_count = len(str(abs(num)))
print("Number of digits:", digit_count)
