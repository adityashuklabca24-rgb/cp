a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
if a > b:
    print("Maximum is:", a)
else:
    print("Maximum is:", b)