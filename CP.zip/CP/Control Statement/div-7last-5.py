num = int(input("Enter a number: "))
if num % 7 == 0 and num % 10 == 5:
    print("Number is divisible by 7 and its last digit is 5.")
else:
    print("Condition not satisfied.")
