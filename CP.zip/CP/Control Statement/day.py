day=int(input("enter the number of day:"))

if(day==1):
    print("sunday")
elif(day==2):
    print("monday")
elif(day==3):
    print("tuesday")
elif(day==4):
    print("wednesday")
elif(day==5):
    print("thursday")
elif(day==6):
    print("friday")
elif(day==7):
    print("saturday")
else:
    print("invailid day")