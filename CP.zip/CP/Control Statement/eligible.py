age=int(input("enter your age:"))
if(age>=18):
    print("this is eligible for vote");
else :
    print("this is not eligible for vote");
