a = int(input("Enter a number: "))
if a % 5 == 0 and a % 11 == 0:
    print("divisible by 5 and 11")
else:
    print(" not divisible by 5 and 11")