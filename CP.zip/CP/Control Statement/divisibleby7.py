n = int(input("\nEnter no: "))

if n % 7 == 0:
    print("\nDivisible by 7")
else:
    print("\nNot divisible by 7")