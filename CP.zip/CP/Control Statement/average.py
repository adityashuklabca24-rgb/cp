a=int(input("enter a number:"))
b=int(input("enter a number:"))
c=int(input("enter a number:"))
d=int(input("enter a number:"))
e=int(input("enter a number:"))

average=(a+b+c+d+e)/5
print("the Average is ",average)