def area_square(a):
    return a*a
