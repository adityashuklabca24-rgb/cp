import math
def area_circle(a):
    return math.pi*a*a
