import math
def area_ellipse(a,b):
    return math.pi*a*b
