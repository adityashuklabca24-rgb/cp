def cube(a):
    return a*a*a
