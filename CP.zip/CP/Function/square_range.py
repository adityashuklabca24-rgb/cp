def square_range(x,y):
    return [i*i for i in range(x,y+1)]
