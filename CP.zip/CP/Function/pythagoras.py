import math
def pythagoras(a,b):
    return math.sqrt(a*a+b*b)
