import math
def volume_sphere(a):
    return (4*math.pi*a**3)/3
