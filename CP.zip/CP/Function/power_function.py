def power(a,b):
    return a**b
