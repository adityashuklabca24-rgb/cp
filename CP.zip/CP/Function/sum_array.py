def sum_array(a):
    return sum(a)
