n=int(input("enter number:"))
m=int(input("enter number:"))
for i in range(0, n):
    for j in range(0, m):
        print("*", end=" ")
    print()  # This will print a newline after the stars