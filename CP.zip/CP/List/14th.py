mylist = [1.4, 2, 3, 4, 5, "Suyash"]
mylist.reverse()
print(mylist)