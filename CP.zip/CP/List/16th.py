l1 = [1, 2, 3, 5, 8, 9]
l2 = [3, 4, 5 , 6, 7, 10]
result = l1 + l2
print(result)
result1 = l1 * 3
print(result1)