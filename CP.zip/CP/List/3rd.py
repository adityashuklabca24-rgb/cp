# # Take input an array A of size N and write a program to print maximum and minimum
#  elements of the input array .Here N represents the length of the array .
l=list(map(int,input("enter:").split()))
print("max:",max(l))
print("min:",min(l))

