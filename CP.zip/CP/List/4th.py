# You are given array A and an integer B. You have to tell whether B is present in array And which index.

l=list(map(int,input("enter:").split()))
b=int(input("enter:"))
print(l.index(b)) 