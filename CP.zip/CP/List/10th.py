# Given an array A, Find the reverse of it. (Solve this question with for loop
numbers = [1, 2, 3, 4, 5]
reversed_list = []

for i in numbers:   
    reversed_list.insert(0, i)  

print(reversed_list)




