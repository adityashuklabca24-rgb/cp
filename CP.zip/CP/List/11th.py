# sum of 2 lists.
A=[1, 2 ,3, 4 ,5]
B=[2,4,6,7,8]
sum=[]
for i in range(len(A)):
    sum.append(A[i]+B[i])
print(sum)