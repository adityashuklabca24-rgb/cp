list = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21]
print(len(list))
print(list[-2 :-5:-1])
print(list[-2:])
print(list[-2::])
print(list[:-2])
print(list[::-2])
print(list[::-1])