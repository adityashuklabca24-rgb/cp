#  Given an array compute the sum of all elements in the array.
l=map(int,input("enter:").split())
print((sum(l)))
