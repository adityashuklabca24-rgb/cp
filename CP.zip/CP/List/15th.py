s= "Hello everyone how are you"
print(s.split())

s="Hello-everyone- how are you"
print(s.split("-"))

word='Suyash:Chaudhary:Noida'
print(word.split(':'))

t="23456"
print(t.split())

t="2 3 4 5"
print(t.split())