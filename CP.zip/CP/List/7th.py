A = list(map(int, input("Enter array elements: ").split()))
for i in A:
    if i%2==0:
        print("even",i,end=" ")
    else:
     print("odd",i,end=" ")
    


   

