#  You are provided with an integerarrayA.Return another array B of size same as that of
#  As such that B[i]=A[i]^2 in a list.
A=list(map(int,input().split()))
B=[i**2 for i in A]
print(B)



    
