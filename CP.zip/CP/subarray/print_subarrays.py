n=int(input())
a=list(map(int,input().split()))
for i in range(n):
    for j in range(i,n):
        print(*a[i:j+1])
